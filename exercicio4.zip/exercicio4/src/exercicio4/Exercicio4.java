package exercicio4;

import java.util.Scanner;

public class Exercicio4 {

    public static void main(String[] args) {
        Scanner kb = new Scanner(System.in);
        double A, B, vT;
        System.out.println("insira valor de A e insira o valor de B");
        A = kb.nextDouble();
        B = kb.nextDouble();
        vT = A;
        A = B;
        B = vT;
        System.out.println("Os valores trocados são respectivamente " + A + " " + B);
    }

}
