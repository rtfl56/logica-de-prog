
package exercicio11sn;

import java.util.Scanner;

public class Exercicio11sn {

    public static void main(String[] args) {
        Scanner kb = new Scanner(System.in);
        double N1, N2;
        System.out.println("digite dois numeros");
        N1 = kb.nextDouble();
        N2 = kb.nextDouble();
        if (N1 < N2){
            System.out.println(N1 + N2);    
        } else {
            System.out.println(N2 + N1);
        }
    }
    
}
