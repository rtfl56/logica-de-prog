
package exercicio5sn;

import java.util.Scanner;

public class Exercicio5sn {

    public static void main(String[] args) {
        Scanner kb = new Scanner(System.in);
        double C, A, L, V;
        System.out.println("Digite respectivamente seu comprimento, altura e largura");
        C = kb.nextDouble();
        A = kb.nextDouble();
        L = kb.nextDouble();
        V = C * A * L;
        System.out.println("Seu volume é " + V);
    }
    
}
