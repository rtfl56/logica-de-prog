
package exercicio7;

import java.util.Scanner;

public class Exercicio7 {

    public static void main(String[] args) {
        Scanner kb = new Scanner(System.in);
        double N;
        System.out.println("Digite seu numero");
        N = kb.nextDouble();
        if ( N % 2 == 0 && N % 3 == 0){
            System.out.println("seu numero é divisivel por 2 e 3");
        } else {
            System.out.println("Seu numero não é divisivel por 2 e 3");1
        }
    }
    
}
