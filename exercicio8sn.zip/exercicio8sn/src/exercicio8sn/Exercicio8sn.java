/
package exercicio8sn;

import java.util.Scanner;

public class Exercicio8sn {

    public static void main(String[] args) {
        Scanner kb = new Scanner(System.in);
        double N;
        System.out.println("Digite seu numero");
        N = kb.nextDouble();
        if (N % 7 == 0 && N % 5 == 0) {
            System.out.println("seu numero é divisivel por 5 e 7");
        } else {
            System.out.println("Seu numero não é divisivel por 5 e 7");
        
    }
    
}
