
package exercicio9sn;

import java.util.Scanner;

public class Exercicio9sn {

    public static void main(String[] args) {
        Scanner kb = new Scanner(System.in);
        double N1, N2;
        System.out.println("Digite dois numeros");
        N1 = kb.nextDouble();
        N2 = kb.nextDouble();
        if (N1 > N2){
            System.out.println("O primeiro numero digitado é o maior");
        } else {
            System.out.println("O segundo é o maior");
        }
    }
    
}
