package exercicio3ng;

import java.util.Scanner;

public class Exercicio3ng {

    public static void main(String[] args) {
        Scanner kb = new Scanner(System.in);
        double R, H, V;
        System.out.println("insira seu raio e a altura");
        R = kb.nextDouble();
        H = kb.nextDouble();
        V = 3.14 * R * R * H;
        System.out.println("seu volume é " + V);
    }

}
