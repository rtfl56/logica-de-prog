
package ex02_fparacelsius;

import java.util.Scanner;

public class Ex02_FparaCelsius {

    public static void main(String[] args) {
        Scanner teclado = new Scanner(System.in);
        
        double F,C;
        System.out.println("Informe a temperatura em Celsius");
        C =  teclado.nextDouble();
        F = (9.0*C+160.0)/5.0;
        System.out.println("A temperatura em Fahrenheit é " + F);
    }
    
}
